<?php
   require('db.php');
   $status = "";
   if(isset($_POST['new']) && $_POST['new']==1)
   {
   $trn_date = date("Y-m-d H:i:s");
   $firstname =$_REQUEST['firstname'];
   $lastname = $_REQUEST['lastname'];
   $dateofbirth = $_REQUEST['dateofbirth'];
   $email = $_REQUEST['email'];
   $phonenumber = $_REQUEST['phonenumber'];

   $ins_query="insert into new_data (`trn_date`,`firstname`,`lastname`,`dateofbirth`,`email`,`phonenumber`) values ('$trn_date','$firstname','$lastname','$dateofbirth','$email','$phonenumber')";
   mysqli_query($con,$ins_query) or die(mysql_error());
   $status = "New Data Inserted Successfully.</br></br><a href='view.php'>View Inserted Data</a>";
   }
   ?>
<!DOCTYPE html>
<html>
   <head>
      <meta charset="utf-8">
      <title>Insert New Data</title>
      <link rel="stylesheet" href="css/style.css" />
   </head>
   <body>
      <div class="form">
         <p><a href="Managing-Page.php">Managing Page</a> | <a href="view.php">View</a></p>
         <div>
            <h1>Insert New Data</h1>
            <form name="form" method="post" action="">
               <input type="hidden" name="new" value="1" />
               <p><input type="text" name="firstname" placeholder="First Name" required /></p>
               <p><input type="text" name="lastname" placeholder="Last Name" required /></p>
               <p><input type="date" name="dateofbirth" placeholder="Date of Birth" required /></p>
               <p><input type="email" name="email" placeholder="Email Address" required /></p>
               <p><input type="tel" name="phonenumber" placeholder="Phone Number" required /></p>
               <p><input name="submit" type="submit" value="Submit" /></p>
            </form>
            <p style="color:#FF0000;"><?php echo $status; ?></p>
         </div>
      </div>
   </body>
</html>