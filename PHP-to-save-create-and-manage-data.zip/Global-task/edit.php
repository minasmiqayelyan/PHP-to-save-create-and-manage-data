<?php
   require('db.php');
   $id=$_REQUEST['id'];
   $query = "SELECT * from new_data where id='".$id."'"; 
   $result = mysqli_query($con, $query) or die ( mysqli_error());
   $row = mysqli_fetch_assoc($result);
   ?>
<!DOCTYPE html>
<html>
   <head>
      <meta charset="utf-8">
      <title>Update Data</title>
      <link rel="stylesheet" href="css/style.css" />
   </head>
   <body>
      <div class="form">
         <p><a href="index.php">Insert New Data</a> | <a href="Managing-Page.php">Managing Page</a> | <a href="view.php">View</a></p>
         <h1>Update Data</h1>
         <?php
            $status = "";
            if(isset($_POST['new']) && $_POST['new']==1)
            {
            $id=$_REQUEST['id'];
            $trn_date = date("Y-m-d H:i:s");
             $firstname =$_REQUEST['firstname'];
               $lastname = $_REQUEST['lastname'];
               $dateofbirth = $_REQUEST['dateofbirth'];
               $email = $_REQUEST['email'];
               $phonenumber = $_REQUEST['phonenumber'];
            $update="update new_data set trn_date='".$trn_date."', firstname='".$firstname."', lastname='".$lastname."', dateofbirth='".$dateofbirth."', email='".$email."', phonenumber='".$phonenumber."' where id='".$id."'";
            mysqli_query($con, $update) or die(mysqli_error());
            $status = "Data Updated Successfully. </br></br><a href='view.php'>View Updated Data</a>";
            echo '<p style="color:#FF0000;">'.$status.'</p>';
            }else {
            ?>
         <div>
            <form name="form" method="post" action="">
               <input type="hidden" name="new" value="1" />
               <input name="id" type="hidden" value="<?php echo $row['id'];?>" />
               <p><input type="text" name="firstname" placeholder="First Name" required value="<?php echo $row['firstname'];?>" /></p>
               <p><input type="text" name="lastname" placeholder="Last Name" required value="<?php echo $row['lastname'];?>" /></p>
               <p><input type="text" name="dateofbirth" placeholder="Date of Birth" required value="<?php echo $row['dateofbirth'];?>" /></p>
               <p><input type="text" name="email" placeholder="Email" required value="<?php echo $row['email'];?>" /></p>
               <p><input type="text" name="phonenumber" placeholder="Phone Number" required value="<?php echo $row['phonenumber'];?>" /></p>
               <p><input name="submit" type="submit" value="Update" /></p>
            </form>
            <?php } ?>
         </div>
      </div>
   </body>
</html>